import requests

url = 'http://localhost:3200/spam'
data = {
    'Id': 1,
    'Subject': 'free promotional offer',
    'Body': 'I will sent it again"'
}

response = requests.post(url, json=data)
print(response.text)