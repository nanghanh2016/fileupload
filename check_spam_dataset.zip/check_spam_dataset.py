#!/usr/bin/env python3
from flask import Flask, request, jsonify
import numpy as np
import string
from joblib import load
import nltk
from nltk.corpus import stopwords
nltk.download('stopwords')

app = Flask(__name__)

def process(text):
    nopunc = [char for char in text if char not in string.punctuation]
    nopunc = ''.join(nopunc)
    clean = [word for word in nopunc.split() if word.lower() not in stopwords.words('english')]
    return clean


def load_model_and_vectorizer(model_path, vectorizer_path):
    model = load(model_path)
    vectorizer = load(vectorizer_path)
    return model, vectorizer

def detect_spam(input_text, model, vectorizer):
    # Preprocess input text
    processed_text = process(input_text)

    # Transform input text using the loaded vectorizer
    vectorized_text = vectorizer.transform(processed_text)
    prediction = model.predict(vectorized_text)

    return prediction

def show_percentage_of_spam(prediction):
    spam_count = np.count_nonzero(prediction == 1)
    ham_count = np.count_nonzero(prediction == 0)

    # Calculate percentages
    total_predictions = len(prediction)
    spam_percentage = (spam_count / total_predictions) * 100
    ham_percentage = (ham_count / total_predictions) * 100

    print(f"Spam: {spam_percentage:.2f}% ")
    print(f"Ham : {ham_percentage:.2f}% ")
    if spam_percentage > 50:
        return "Spam: True ; 15 / 5\r\n"
    else:
        return  "Spam: False ; 2 / 5\r\n"

def detectModel(msg: str):
    model, vectorizer = load_model_and_vectorizer("./model.pkl", "./vectorizer.pkl")
    prediction = detect_spam(msg, model, vectorizer)
    return show_percentage_of_spam(prediction)

@app.route('/spam', methods=['POST'])
def spam():
    data = request.get_json()
    print(data)

    msg = data['Subject'] + ' ' + data['Body']
    msg = msg.replace("\r\n", " ").replace("\r", "")

    return detectModel(msg);

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=3200)  # Use any host and port number you want