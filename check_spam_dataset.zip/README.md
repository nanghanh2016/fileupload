##  Environment Setup
python -m venv .venv
.venv/Scripts/activate
python.exe -m pip install --upgrade pip
pip install -r requirements.txt

## Running the server
python check_spam_dataset.py

## Testing
python test.py
